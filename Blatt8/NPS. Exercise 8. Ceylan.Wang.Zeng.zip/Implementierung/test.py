import numpy as np 

x = np.array([2,3,4])

x = (x**2)**0.5
print(x) 